<!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.10.1/mdb.min.js"
></script>
<?php /**PATH C:\Users\Nikola\Desktop\radnja\resources\views/layouts/bs_js.blade.php ENDPATH**/ ?>