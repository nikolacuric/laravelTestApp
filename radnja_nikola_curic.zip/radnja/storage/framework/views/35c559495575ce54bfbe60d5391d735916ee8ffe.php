<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.bs_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.ftr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
</html>
<script>

    $(document).ready(function() {
        $('#data_table').DataTable();
    } );
    
</script><?php /**PATH C:\Users\Nikola\Desktop\radnja\resources\views/layouts/app.blade.php ENDPATH**/ ?>