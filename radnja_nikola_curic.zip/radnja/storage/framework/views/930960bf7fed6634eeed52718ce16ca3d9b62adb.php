
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<section>
    <div class="container my-5">
        <div class="row justify-content-center align_items_center">
            <div class="col-3 p-3 border rounded">
                <form action="/login" method="POST">
                  <?php echo csrf_field(); ?>
                    <!-- ne ide csrf jer ovaj route ne ide preko resource -->
                    <!-- Email input -->
                    <label class="form-label" for="form1Example1">Email address</label>
                    <div class="form-outline mb-4">
                      <input name = "email" type="email" id="form1Example1" class="form-control border" />
                    </div>
                  
                    <!-- Password input -->
                    <label class="form-label" for="form1Example2">Password</label>
                    <div class="form-outline mb-4">
                      <input name = "password" type="password" id="form1Example2" class="form-control border" />
                    </div>                  
                  
                    <!-- Submit button -->
                    <button type="submit" class="btn btn-primary btn-block">Sign in</button>
                  </form>
            </div>
        </div>
    </div>
</section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nikola\Desktop\radnja\resources\views/app/login.blade.php ENDPATH**/ ?>