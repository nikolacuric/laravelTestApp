

<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
    <div class="alert <?php echo e(session('alertColor')); ?>" role="alert">
    <?php echo e(session('message')); ?>

  </div>
<?php endif; ?>

<section class="my-3 d-flex justify-content-end">
    <a href="/products/create"
        <?php if($_SESSION["rights"]!=="admin"): ?>
            hidden
        <?php endif; ?>
    >
        <button class="btn btn-primary me-5"
            <?php if($_SESSION["rights"]!=="admin"): ?>
                hidden
            <?php endif; ?>
        >
            Create a new product
        </button> 
    </a>
</section>

<section class="my-5 text-center">
    <h3>Products</h3>
</section>
<section class="my-5">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-10">
                <table id="data_table" class="table border table-bordered table-striped">
                    <thead>
                        <tr class="">
                            <th>Product Key</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Category Name</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->product_key); ?></td>
                                <td><?php echo e($product->product_name); ?></td>
                                <td><?php echo e($product->description); ?></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($categories[$product->category_ID_category]); ?></td>
                                <form action="/products/<?php echo e($product->ID_product); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("delete"); ?>
                                    <td>
                                        <button 
                                            type="submit" 
                                            class="btn-sm btn-danger"
                                            <?php if($_SESSION["rights"]!=="admin"): ?>
                                                disabled
                                            <?php endif; ?> 
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </form>
                                
                                <td>
                                    <a href="/products/<?php echo e($product->ID_product); ?>/edit">
                                        <button 
                                            class="btn-sm btn-warning"
                                            <?php if($_SESSION["rights"]!=="admin"): ?>
                                                disabled
                                            <?php endif; ?>
                                        >
                                            Update
                                        </button> 
                                    </a>
                                </td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nikola\Desktop\radnja\resources\views/app/products.blade.php ENDPATH**/ ?>