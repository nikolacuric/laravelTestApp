

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger" role="alert">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($e); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<section>
  <div class="container-fluid my-5">
    <div class="row justify-content-center align-items-center">
      <div class="col-3">
        <form action="/categories/<?php echo e($category["ID_category"]); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <!-- Name input -->
            <label class="form-label" for="form4Example1">Category Name</label>
            <div class="form-outline mb-4">
              <input 
                name="category_name" 
                value="<?php echo e($category["category_name"]); ?>" 
                type="text" 
                id="form4Example1" 
                class="form-control rounded border" />
            </div>
          
            <!-- Submit button -->
            <button type="submit" class="btn btn-primary btn-block mb-4">Insert</button>
          </form>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nikola\Desktop\radnja\resources\views/app/editCategory.blade.php ENDPATH**/ ?>