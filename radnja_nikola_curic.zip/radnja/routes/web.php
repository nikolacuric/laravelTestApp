<?php

session_start();

if (!isset($_SESSION['rights'])) {
    $_SESSION['rights'] = "";
}

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoriesController;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\UsersController;


function checkRights(string $rights): bool
{
    if (isset($_SESSION['rights']) && $_SESSION['rights'] === $rights) {
        return true;
    }else{
        return false;  
    }
}


if (checkRights('admin')) {
    Route::resource("/categories", CategoriesController::class);
    Route::resource("/products", ProductsController::class);
    Route::resource("/users", UsersController::class);
    Route::get("/welcome",[LoginController::class,"welcome"]);
    Route::get("/logout",[LoginController::class,"logout"]);    
}elseif(checkRights('user')){
    Route::get("/categories",[CategoriesController::class,"index"]);
    Route::get("/categories/show/{id}",[CategoriesController::class,"show"]);
    Route::get("/products",[ProductsController::class,"index"]);
    Route::get("/welcome",[LoginController::class,"welcome"]);
    Route::get("/logout",[LoginController::class,"logout"]);
}else{
    Route::get("/",[LoginController::class,"index"]);
    Route::post("/login",[LoginController::class,"authUser"]);
}

