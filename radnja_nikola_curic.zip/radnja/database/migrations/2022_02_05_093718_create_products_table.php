<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id("ID_product");
            $table->string("product_key",30);
            $table->string('product_name', 100);
            $table->text("description");
            $table->unsignedDecimal('price', $precision = 8, $scale = 2);
            $table->string("img_path",100);
            $table->bigInteger("category_ID_category");
            $table->foreign("category_ID_category")
                ->references("ID_category")
                ->on("categories")
                ->onUpdate("cascade")
                ->onDelete("cascade");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
