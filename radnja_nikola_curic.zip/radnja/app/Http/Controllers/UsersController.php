<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserValidationRequest;
use Illuminate\Http\Request;
use App\Models\User;

class UsersController extends Controller
{
    private function encryptPass(string $pass): string{
        $options = [
            'cost' => 12,
        ];
        return password_hash($pass, PASSWORD_BCRYPT, $options);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();
        return view('app.ad.user',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("app.ad.addUser");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserValidationRequest $request)
    {
        $request->validated();
        $request->validate([
            "email"=>"unique:users"
        ]);

        $create = User::create([
            "name"=>$request->input('name'),
            "email"=>$request->input('email'),
            "password"=>$this->encryptPass($request->input('password')),
            "rights"=>$request->input('rights')
        ]);
        if ($create) {
            $message = "Successfuly created!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! User not created.";
            $alertColor = "alert-danger";
        }
        return redirect("/users")
            ->with([
                'message'   =>$message,
                'alertColor'=>$alertColor
            ]
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $usersInRights = User::find($id);

        return view("app.ad.usersInRights")
            ->with([
                "users"=>$usersInRights
            ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        $user = User::find($id)->toArray();
        return view("app.ad.editUser",compact("user"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserValidationRequest $request, $id)
    {
        $request->validated();

        $update = User::where("ID_user",$id)
            ->update([
                "name"=>$request->input("name"),
                "email"=>$request->input("email"),
                "password"=>$this->encryptPass($request->input('password')),
                "rights"=>$request->input('rights')
            ]);
        if ($update) {
            $message = "Successfuly updated!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! User not updated.";
            $alertColor = "alert-danger";
        }

        return redirect("/users")->with([
            "message" => $message,
            'alertColor'=>$alertColor
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $delete = User::destroy($id);
        if ($delete) {
            $message = "Successfuly deleted!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! User not deleted.";
            $alertColor = "alert-danger";
        }
        return redirect("/users")->with([
            "message" => $message,
            "alertColor"=>$alertColor
        ]);
    }
}
