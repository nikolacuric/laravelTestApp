<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginValidationRequest;
use App\Models\User;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view("app.login");
    }

    public function welcome()
    {
        return view("app.welcome");
    }
    public function logout()
    {   
        $_SESSION['rights'] = "";
        return redirect("/");
    }

    public function authUser(LoginValidationRequest $request)
    {
        $request->validated();
        
        $user = User::where("email", $request->input("email"))
            ->get()->first();

        if (password_verify($request->input("password"), $user->password)) {
            $_SESSION['rights'] = $user->rights;
            return redirect("/welcome");
        } else {
            $_SESSION['rights'] = "";
            return redirect("/");
        }
            
    }
}
