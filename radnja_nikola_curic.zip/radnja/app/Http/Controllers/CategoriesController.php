<?php

namespace App\Http\Controllers;

use App\Http\Requests\CategoryValidationRequest;
use App\Models\Category;
use Facade\FlareClient\Http\Response;
use Illuminate\Http\Request;

class CategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::all();
        return view('app.category',compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("app.addCategory");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryValidationRequest $request)
    {
        $request->validated();
        $request->validate([
            "category_name"=>"unique:categories"
        ]);
        // --> Without fillable property
        // $category = new Category();
        // $category->category_name = $request->input('catName');
        // $category->save();

        // --> With fillable property
        if (
            Category::create([
            "category_name"=>$request->input('category_name')
            ])
        ){
            $message = "Successfuly created!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! Category not created.";
            $alertColor = "alert-danger";
        }
        return redirect("/categories")
            ->with([
                'message'   =>$message,
                'alertColor'=>$alertColor
            ]
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $productsInCategory = Category::find($id);
        //dd($productsInCategory);
        //var_dump($productsInCategory);
        return view("app.productsInCategory")
            ->with([
                "products"=>$productsInCategory
            ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        $category = Category::find($id)->toArray();
        return view("app.editCategory",compact("category"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CategoryValidationRequest $request, $id)
    {
        $request->validated();

        if(
            Category::where("ID_category",$id)
            ->update([
                "category_name"=>$request->input("category_name")
            ])
        ){
            $message = "Successfuly updated!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! Category not updated.";
            $alertColor = "alert-danger";
        }

        return redirect("/categories")->with([
            "message"   => $message,
            "alertColor"=>$alertColor
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if(
            Category::destroy($id)
        ){
            $message = "Successfuly deleted!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! Category not deleted.";
            $alertColor = "alert-danger";
        }
        return redirect("/categories")->with([
            "message" => $message,
            "alertColor"=>$alertColor
        ]);
    }
}
