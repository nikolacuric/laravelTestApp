@extends('layouts.app')

@section('content')


<section class="my-5 text-center" style="height:600px;">
    <h3>Welcome page</h3>
</section>
@endsection