@extends('layouts.app')

@section('content')
<section class="my-5 text-center">
    <h3>Products in category</h3>
</section>
<section class="my-5">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-10">
                <table id="data_table" class="table table-bordered border table-striped">
                    <thead>
                        <tr class="">
                            <th>Product Key</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Category Name</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($products->productClass as $product)
                            <tr>
                                <td>{{ $product->product_key }}</td>
                                <td>{{ $product->product_name }}</td>
                                <td>{{ $product->description }}</td>
                                <td>{{ $product->price }}</td>
                                <td>{{ $product->category_name }}</td>
                                <form action="/products/{{ $product->ID_product }}" method="POST">
                                    @csrf
                                    @method("delete")
                                    <td>
                                        <button type="submit" class="btn-sm btn-danger" >
                                            Delete
                                        </button>
                                    </td>
                                </form>
                                <td>
                                    <a href="/products/{{ $product->ID_product }}/edit">
                                        <button class="btn-sm btn-warning">
                                            Update
                                        </button> 
                                    </a>
                                </td> 
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection