<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Http\Requests\ProductValidationRequest;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = 
            array_column(
                Category::all()->toArray(),
                "category_name", 
                "ID_category"
            );
        $products = Product::all();
        return view('app.products',compact('products','categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = 
        array_column(
            Category::all()->toArray(),
            "category_name", 
            "ID_category"
        );
        return view("app.addProduct",compact("categories"));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProductValidationRequest $request)
    {
        $request->validated();
        $request->validate([
            "product_key"=>"unique:products",
            "product_name"=>"unique:products",
        ]);

        if(
            // --> With fillable property
            Product::create([
                "product_key"=>$request->input("product_key"),
                "product_name"=>$request->input("product_name"),
                "description"=>$request->input("description"),
                "price"=>$request->input("price"),
                "img_path"=>"adfasdf/adsfasdf/sadfsdf.png",
                "category_ID_category"=>$request->input("category_ID_category")
            ])
        ) {
            $message = "Successfuly created!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! Category not created.";
            $alertColor = "alert-danger";
        }
        return redirect("/products")
            ->with([
                'message'   =>$message,
                'alertColor'=>$alertColor
            ]
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        $categories = 
        array_column(
            Category::all()->toArray(),
            "category_name", 
            "ID_category"
        );
        $product = Product::find($id)->toArray();
        return view("app.editProduct",compact("product","categories"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ProductValidationRequest $request, $id)
    {
        $request->validated();

        if (
            Product::where("ID_product",$id)
                ->update([
                    "product_key"=>$request->input("product_key"),
                    "product_name"=>$request->input("product_name"),
                    "description"=>$request->input("description"),
                    "price"=>$request->input("price"),
                    "img_path"=>"adfasdf/adsfasdf/sadfsdf.png",
                    "category_ID_category"=>$request->input("category_ID_category")
                ])
        ) {
            $message = "Successfuly updated!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! Product not updated.";
            $alertColor = "alert-danger";
        }

        return redirect("/products")->with([
            "message" => $message,
            "alertColor" => $alertColor
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $destroy = Product::destroy($id);
        if ($destroy) {
            $message = "Successfuly deleted!";
            $alertColor = "alert-success";
        } else {
            $message = "Something went wrong! Product not deleted.";
            $alertColor = "alert-danger";
        }
        return redirect("/products")->with([
            "message" => $message,
            "alertColor" => $alertColor
        ]);
        
    }
}
