

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

    <section>
        <div class="container-fluid my-5">
            <div class="row justify-content-center align-items-center">
                <div class="col-4">
                    <form action="/products/<?php echo e($product['ID_product']); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <!-- Name input -->
                        <label class="form-label" for="form4Example1">Product Key</label>
                        <div class="form-outline mb-4">
                        <input 
                                value="<?php echo e($product['product_key']); ?>"
                                name = "product_key" 
                                type="text" 
                                id="form4Example1" 
                                class="form-control rounded border" 
                            />
                        </div>

                        <label class="form-label" for="form4Example1">Product Name</label>
                        <div class="form-outline mb-4">
                            <input 
                                value="<?php echo e($product['product_name']); ?>"
                                name = "product_name" 
                                type="text" 
                                id="form4Example1" 
                                class="form-control rounded border" 
                            />
                        </div>
                        <label class="form-label" for="form4Example1">Description</label>
                        <div class="form-outline mb-4">
                            <input 
                                value="<?php echo e($product['description']); ?>"
                                name = "description" 
                                type="text" 
                                id="form4Example1" 
                                class="form-control rounded border" 
                            />
                        </div>

                        <label class="form-label" for="form4Example1">Price</label>
                        <div class="form-outline mb-4">
                            <input 
                                value="<?php echo e($product['price']); ?>"
                                name = "price" 
                                type="text" 
                                id="form4Example1" 
                                class="form-control rounded border"
                            />
                        </div>
                        
                        <label class="form-label" for="form4Example1">Category Name</label>
                        <div class="form-outline mb-4">
                            <select 
                                id="form4Example1"
                                name = "category_ID_category"
                                class="form-control rounded border"
                            >
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    
                        <!-- Submit button -->
                        <button type="submit" class="btn btn-primary btn-block mb-4">
                            Insert
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nikola\Desktop\radnja\resources\views/app/editProduct.blade.php ENDPATH**/ ?>