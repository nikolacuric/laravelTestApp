

<?php $__env->startSection('content'); ?>


<section class="my-5 text-center" style="height:600px;">
    <h3>Welcome page</h3>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nikola\Desktop\radnja\resources\views/app/welcome.blade.php ENDPATH**/ ?>