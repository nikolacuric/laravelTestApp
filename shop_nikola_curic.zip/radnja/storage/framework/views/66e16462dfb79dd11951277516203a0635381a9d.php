

<?php $__env->startSection('content'); ?>
<section class="my-5 text-center">
    <h3>Products in category</h3>
</section>
<section class="my-5">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-10">
                <table id="data_table" class="table table-bordered border table-striped">
                    <thead>
                        <tr class="">
                            <th>Product Key</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Category Name</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products->productClass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->product_key); ?></td>
                                <td><?php echo e($product->product_name); ?></td>
                                <td><?php echo e($product->description); ?></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($product->category_name); ?></td>
                                <form action="/products/<?php echo e($product->ID_product); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("delete"); ?>
                                    <td>
                                        <button type="submit" class="btn-sm btn-danger" >
                                            Delete
                                        </button>
                                    </td>
                                </form>
                                <td>
                                    <a href="/products/<?php echo e($product->ID_product); ?>/edit">
                                        <button class="btn-sm btn-warning">
                                            Update
                                        </button> 
                                    </a>
                                </td> 
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nikola\Desktop\radnja\resources\views/app/productsInCategory.blade.php ENDPATH**/ ?>