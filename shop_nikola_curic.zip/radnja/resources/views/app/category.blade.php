@extends('layouts.app')

@if (session('message'))
    <div class="alert {{ session('alertColor') }}" role="alert">
    {{ session('message') }}
  </div>
@endif

@section('content')
<section class="my-3 d-flex justify-content-end">
    <a href="/categories/create"
        @if ($_SESSION["rights"]!=="admin")
            hidden
        @endif
    >
        <button 
        class="btn btn-primary me-5"
            @if ($_SESSION["rights"]!=="admin")
                hidden
            @endif
        >
            Create a new category
        </button> 
    </a>
</section>

<section class="my-5 text-center">
    <h3>Product categories</h3>
</section>

<section class="my-5">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-6 p-3 rounded">
                <table class="table border table-bordered table-striped" id="data_table">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Delete</th>
                            <th>Update</th>
                            <th>See product of matched category</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($categories as $category)
                            <tr>
                                <td>{{ $category['category_name'] }}</td>
                                <td>
                                    <form action="/categories/{{ $category['ID_category'] }}" 
                                        method="POST">
                                        @csrf
                                        @method('delete')
                                        <button 
                                            type="submit" 
                                            class="btn-sm btn-danger"
                                            @if ($_SESSION["rights"]!=="admin")
                                                disabled
                                            @endif
                                        >
                                            Delete
                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <a href="/categories/{{ $category['ID_category'] }}/edit">
                                        <button 
                                            class="btn-sm btn-warning"
                                            @if ($_SESSION["rights"]!=="admin")
                                                disabled
                                            @endif
                                        >
                                            Update
                                        </button>
                                    </a>
                                    
                                </td>
                                <td>
                                    <a
                                        @if ($_SESSION["rights"]!=="admin")
                                            href="/categories/show/{{ $category['ID_category'] }}"
                                        @else
                                            href="/categories/{{ $category['ID_category'] }}"
                                        @endif
                                        class="font-weight-bold"
                                    >
                                    See all products in category {{ $category['category_name'] }} &#x2192;
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection