@extends('layouts.app')
@section('content')
@if ($errors->any())
    <div class="alert alert-danger" role="alert">
        @foreach ($errors->all() as $e)
            <li>{{ $e }}</li>
        @endforeach
    </div>
@endif

<section>
    <div class="container my-5">
        <div class="row justify-content-center align_items_center">
            <div class="col-3 p-3 border rounded">
                <form action="/login" method="POST">
                  @csrf
                    <!-- ne ide csrf jer ovaj route ne ide preko resource -->
                    <!-- Email input -->
                    <label class="form-label" for="form1Example1">Email address</label>
                    <div class="form-outline mb-4">
                      <input name = "email" type="email" id="form1Example1" class="form-control border" />
                    </div>
                  
                    <!-- Password input -->
                    <label class="form-label" for="form1Example2">Password</label>
                    <div class="form-outline mb-4">
                      <input name = "password" type="password" id="form1Example2" class="form-control border" />
                    </div>                  
                  
                    <!-- Submit button -->
                    <button type="submit" class="btn btn-primary btn-block">Sign in</button>
                  </form>
            </div>
        </div>
    </div>
</section>
  @endsection