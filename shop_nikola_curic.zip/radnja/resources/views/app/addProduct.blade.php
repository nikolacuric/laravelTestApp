@extends('layouts.app')

@section('content')

  @if ($errors->any())
      <div class="alert alert-danger" role="alert">
          @foreach ($errors->all() as $e)
              <li>{{ $e }}</li>
          @endforeach
      </div>
  @endif

  <section>
    <div class="container-fluid my-5">
      <div class="row justify-content-center align-items-center">
        <div class="col-4">
          <form action="/products" method="POST">
              @csrf
           
              <label class="form-label" for="form4Example1">Product Key</label>
              <div class="form-outline mb-4">
                <input 
                  name = "product_key" 
                  type="text" 
                  id="form4Example1" 
                  class="form-control rounded border" 
                />
              </div>

              <label class="form-label" for="form4Example1">Product Name</label>
              <div class="form-outline mb-4">
                  <input 
                    name = "product_name" 
                    type="text" 
                    id="form4Example1" 
                    class="form-control rounded border" 
                  />
              </div>

              <label class="form-label" for="form4Example1">Description</label>
              <div class="form-outline mb-4">
                <input 
                  name = "description" 
                  type="text" 
                  id="form4Example1" 
                  class="form-control rounded border" 
                />
              </div>

              <label class="form-label" for="form4Example1">Price</label>
              <div class="form-outline mb-4">
                <input 
                  name = "price" 
                  type="text" 
                  id="form4Example1" 
                  class="form-control rounded border" 
                />
              </div>

              <label class="form-label" for="form4Example1">Category Name</label>
              <div class="form-outline mb-4">
                <select 
                    id="form4Example1"
                    name = "category_ID_category"
                    class="form-control rounded border"
                >
                    @foreach ($categories as $key=>$value)
                        <option value="{{ $key }}">{{ $value }}</option>
                    @endforeach
                </select>
              </div>
            
              <!-- Submit button -->
              <button type="submit" class="btn btn-primary btn-block mb-4">
                Insert
              </button>
            </form>
          </div>
        </div>
    </div>
  </section>
@endsection