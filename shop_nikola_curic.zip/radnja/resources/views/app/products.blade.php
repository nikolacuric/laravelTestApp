@extends('layouts.app')

@section('content')

@if (session('message'))
    <div class="alert {{ session('alertColor') }}" role="alert">
    {{ session('message') }}
  </div>
@endif

<section class="my-3 d-flex justify-content-end">
    <a href="/products/create"
        @if ($_SESSION["rights"]!=="admin")
            hidden
        @endif
    >
        <button class="btn btn-primary me-5"
            @if ($_SESSION["rights"]!=="admin")
                hidden
            @endif
        >
            Create a new product
        </button> 
    </a>
</section>

<section class="my-5 text-center">
    <h3>Products</h3>
</section>
<section class="my-5">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-10">
                <table id="data_table" class="table border table-bordered table-striped">
                    <thead>
                        <tr class="">
                            <th>Product Key</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Category Name</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($products as $product)
                            <tr>
                                <td>{{ $product->product_key }}</td>
                                <td>{{ $product->product_name }}</td>
                                <td>{{ $product->description }}</td>
                                <td>{{ $product->price }}</td>
                                <td>{{ $categories[$product->category_ID_category] }}</td>
                                <form action="/products/{{ $product->ID_product }}" method="POST">
                                    @csrf
                                    @method("delete")
                                    <td>
                                        <button 
                                            type="submit" 
                                            class="btn-sm btn-danger"
                                            @if ($_SESSION["rights"]!=="admin")
                                                disabled
                                            @endif 
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </form>
                                
                                <td>
                                    <a href="/products/{{ $product->ID_product }}/edit">
                                        <button 
                                            class="btn-sm btn-warning"
                                            @if ($_SESSION["rights"]!=="admin")
                                                disabled
                                            @endif
                                        >
                                            Update
                                        </button> 
                                    </a>
                                </td>
                                
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection