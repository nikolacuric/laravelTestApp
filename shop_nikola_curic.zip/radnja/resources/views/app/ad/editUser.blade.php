@extends('layouts.app')
@section('content')
@if ($errors->any())
    <div class="alert alert-danger" role="alert">
        @foreach ($errors->all() as $e)
            <li>{{ $e }}</li>
        @endforeach
    </div>
@endif
<section>
    <div class="container-fluid my-5">
        <div class="row justify-content-center align-items-center">
            <div class="col-4">
                <form action="/users/{{ $user['ID_user'] }}" method="POST">
                    @csrf
                    @method("PUT")
                    <!-- Name input -->
                    <label class="form-label" for="form4Example1">Name</label>
                    <div class="form-outline mb-4">
                    <input 
                            value="{{ $user['name'] }}"
                            name = "name" 
                            type="text" 
                            id="form4Example1" 
                            class="form-control border rounded" 
                        />
                    </div>

                    <label class="form-label" for="form4Example1">Email</label>
                    <div class="form-outline mb-4">
                        <input 
                            value="{{ $user['email'] }}"
                            name = "email" 
                            type="text" 
                            id="form4Example1" 
                            class="form-control border rounded" 
                        />
                    </div>
                    
                    <label class="form-label" for="form4Example1">Password</label>
                    <div class="form-outline mb-4">
                        <input 
                            name = "password" 
                            type="password" 
                            id="form4Example1" 
                            class="form-control border rounded" 
                        />
                    </div>

                    <label class="form-label" for="form4Example1">Rights</label>
                    <div class="form-outline mb-4">
                        <select 
                            name="rights" 
                            id="form4Example1"
                            name = "category_ID_category"
                            class="form-control border rounded"
                        >
                            <option value="admin">Admin</option>
                            <option value="user">User</option>
                        </select>
                    </div>
                
                    <!-- Submit button -->
                    <button type="submit" class="btn btn-primary btn-block mb-4">
                        Insert
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection