@extends('layouts.app')

@section('content')

@if (session('message'))
    <div class="alert {{ session('alertColor') }}" role="alert">
    {{ session('message') }}
  </div>
@endif

<section class="my-3 d-flex justify-content-end">
    <a href="/users/create">
        <button class="btn btn-primary me-5">
            Add new user
        </button> 
    </a>
</section>

<section class="my-5 text-center">
    <h3>Users</h3>
</section>

<section class="my-5">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-6">
                <table class="table border table-bordered table-striped" id="data_table">
                    <thead>
                        <tr class="">
                            <th>Name</th>
                            <th>Email</th>
                            <th>Rights</th>
                            <th>Delete</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $user)
                            <tr>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>{{ $user->rights }}</td>
                                <form action="/users/{{ $user->ID_user }}" method="POST">
                                    @csrf
                                    @method("delete")
                                    <td>
                                        <button type="submit" class="btn-sm btn-danger">
                                            Delete
                                        </button>
                                    </td>
                                </form>
                                
                                <td>
                                    <a href="/users/{{ $user->ID_user }}/edit">
                                        <button class="btn-sm btn-warning">
                                            Update
                                        </button> 
                                    </a>
                                </td>
                                
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection