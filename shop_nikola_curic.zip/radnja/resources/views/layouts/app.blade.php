<!DOCTYPE html>
<html lang="en">
<head>
    @include('layouts.head')
</head>
<body>
    @include('layouts.header')
    @include('layouts.bs_js')

        @yield('content')

    @include('layouts.ftr')


</body>
</html>
<script>

    $(document).ready(function() {
        $('#data_table').DataTable();
    } );
    
</script>