<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Seeder;



class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Category::factory()->count(3)->create();
        Product::factory()->count(5)->create();
        User::factory()->count(5)->create();
        
        //default values for the tester
        User::factory([
            'name' => "test",
            'email' => "test@gmail.com",
            'email_verified_at' => now(),
            'password' => '$2y$12$9Oauks9wb6o2e78mZsw6HOoRq72IC/R/CC30FiG4KiuFkZ/RT2q1C', // password
            'remember_token' => 'testToken',
            'rights' => 'admin',
        ])->create();
    }
}
